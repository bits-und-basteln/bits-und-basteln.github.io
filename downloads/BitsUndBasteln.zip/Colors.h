#ifndef Colors_h
#define Colors_h

#define BLACK 0x000000
#define BLUE 0x0000FF
#define RED 0xFF0000
#define LIME 0x00FF00
#define GREEN 0x008000
#define CYAN 0x00FFFF
#define PURPLE 0x800080
#define YELLOW 0xFFFF00
#define WHITE 0xFFFFFF
#define MAGENTA 0xFF00FF

#endif