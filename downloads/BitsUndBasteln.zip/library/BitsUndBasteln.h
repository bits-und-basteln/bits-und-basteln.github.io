#ifndef BitsUndBasteln_h
#define BitsUndBasteln_h

#include "Canvas.h"
#include "images/Images.h"
#include "Colors.h"

#endif