#ifndef Images_h
#define Images_h

#include "Ghost.h"
#include "Hat.h"

#endif